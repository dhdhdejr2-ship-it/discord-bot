# Discord Bot

A moderation + community Discord bot: bans/kicks/timeouts, warnings, lock/unlock,
purge, `/say`, polls, giveaways, a button-based ticket system, and welcome/leave
messages.

## Commands

Every command works both ways: as a `/slash` command and as a `!prefix` text command.

- `!ban @user [reason]`, `!unban <user_id> [reason]`, `!kick @user [reason]`
- `!timeout @user <minutes> [reason]`, `!untimeout @user [reason]`
- `!warn @user <reason>`, `!warnings @user`, `!clearwarnings @user` (stored in `data/warnings.json`)
- `!purge <1-100>` — bulk delete messages
- `!lock`, `!unlock` — lock/unlock the current channel
- `!say <message>` — deletes your message and reposts it as the bot
- `!roll [sides] [count]`, `!coinflip`
- `!poll Question? | Option 1 | Option 2 | ...` (up to 5 options)
- `!giveaway <duration e.g. 10m> <winners> <prize>` — button-based giveaway with automatic winner selection
- `!ticket-setup [title]` — posts a panel; clicking "Open Ticket" creates a private ticket channel

Welcome/leave messages post automatically to `WELCOME_CHANNEL_ID` / `LEAVE_CHANNEL_ID` if set.

**Important:** prefix commands require the **Message Content Intent** to be
turned on for your bot. In the Discord Developer Portal → your application →
**Bot** tab → enable "Message Content Intent" (under Privileged Gateway
Intents), then save. Without this, `!` commands will silently not work.

## Local setup

1. Copy `.env.example` to `.env` and fill in `DISCORD_TOKEN` and `CLIENT_ID`
   (from the Discord Developer Portal). Set `GUILD_ID` too while testing —
   guild-specific commands register instantly instead of waiting up to an hour.
2. Install deps from the repo root: `pnpm install`
3. Register the slash commands: `pnpm --filter @workspace/discord-bot run deploy-commands`
4. Run the bot: `pnpm --filter @workspace/discord-bot run dev`

## Deploying to Railway

1. Push this project to a GitHub repo and connect that repo in Railway (or connect
   the `discord-bot` folder specifically if deploying just this package).
2. In Railway → your service → **Variables**, add: `DISCORD_TOKEN`, `CLIENT_ID`,
   and optionally `GUILD_ID`, `WELCOME_CHANNEL_ID`, `LEAVE_CHANNEL_ID`, `TICKET_CATEGORY_ID`.
3. Set the service's **Root Directory** to `discord-bot` (if deploying the whole
   monorepo) so Railway builds only this package.
4. Build command: `npm install && npm run build`. Start command: `npm run start`.
5. After the first deploy, run `npm run deploy-commands` once (Railway's "Run a
   one-off command" / shell) to register the slash commands with Discord. You only
   need to re-run this when you add or change commands.

## Required bot permissions/intents

In the Discord Developer Portal → Bot tab, make sure these are enabled if you
plan to expand the bot later: **Server Members Intent** (needed for welcome/leave
and is already requested here). Invite the bot with the `bot` and
`applications.commands` scopes and at least: Manage Roles, Kick Members, Ban
Members, Moderate Members, Manage Channels, Manage Messages.
