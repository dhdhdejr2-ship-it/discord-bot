import { Client, EmbedBuilder, TextChannel } from "discord.js";
import { giveawaysStore } from "./storage.js";

export function scheduleGiveawayEnd(client: Client, messageId: string, delayMs: number): void {
  // setTimeout is fine here since this bot runs as a single long-lived
  // process; if the process restarts mid-giveaway, `resumePendingGiveaways`
  // (called on startup) re-schedules anything still pending.
  setTimeout(() => {
    void endGiveaway(client, messageId);
  }, delayMs);
}

export function resumePendingGiveaways(client: Client): void {
  const now = Date.now();
  for (const giveaway of giveawaysStore.all()) {
    if (giveaway.ended) continue;
    const remaining = new Date(giveaway.endsAt).getTime() - now;
    scheduleGiveawayEnd(client, giveaway.messageId, Math.max(remaining, 0));
  }
}

async function endGiveaway(client: Client, messageId: string): Promise<void> {
  const giveaway = giveawaysStore.findByMessageId(messageId);
  if (!giveaway || giveaway.ended) return;
  giveawaysStore.markEnded(messageId);

  const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
  if (!(channel instanceof TextChannel)) return;

  const winners = pickWinners(giveaway.participants, giveaway.winnerCount);

  const embed = new EmbedBuilder()
    .setTitle("🎉 Giveaway Ended!")
    .setColor(0x99aab5)
    .setDescription(
      winners.length > 0
        ? `**Prize:** ${giveaway.prize}\n**Winner(s):** ${winners.map((id) => `<@${id}>`).join(", ")}`
        : `**Prize:** ${giveaway.prize}\nNo one entered — no winner this time.`,
    );

  await channel.send({ embeds: [embed] });
}

function pickWinners(participants: string[], count: number): string[] {
  const pool = [...participants];
  const winners: string[] = [];
  while (winners.length < count && pool.length > 0) {
    const index = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(index, 1)[0]);
  }
  return winners;
}
