import { Client } from "discord.js";
import { resumePendingGiveaways } from "../giveawayRunner.js";

export function registerReadyEvent(client: Client): void {
  client.once("ready", (readyClient) => {
    console.log(`Logged in as ${readyClient.user.tag}`);
    resumePendingGiveaways(readyClient);
  });
}
