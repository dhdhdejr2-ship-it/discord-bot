import { Client, EmbedBuilder, TextChannel } from "discord.js";
import { config } from "../config.js";

export function registerWelcomeLeaveEvents(client: Client): void {
  client.on("guildMemberAdd", async (member) => {
    if (!config.welcomeChannelId) return;
    const channel = await client.channels.fetch(config.welcomeChannelId).catch(() => null);
    if (!(channel instanceof TextChannel)) return;

    const embed = new EmbedBuilder()
      .setTitle("👋 Welcome!")
      .setColor(0x57f287)
      .setDescription(`Welcome to **${member.guild.name}**, ${member}! We're glad you're here.`)
      .setThumbnail(member.user.displayAvatarURL())
      .setFooter({ text: `Member #${member.guild.memberCount}` });

    await channel.send({ embeds: [embed] });
  });

  client.on("guildMemberRemove", async (member) => {
    if (!config.leaveChannelId) return;
    const channel = await client.channels.fetch(config.leaveChannelId).catch(() => null);
    if (!(channel instanceof TextChannel)) return;

    const embed = new EmbedBuilder()
      .setTitle("👋 Goodbye")
      .setColor(0xed4245)
      .setDescription(`**${member.user.tag}** has left **${member.guild.name}**.`)
      .setThumbnail(member.user.displayAvatarURL());

    await channel.send({ embeds: [embed] });
  });
}
