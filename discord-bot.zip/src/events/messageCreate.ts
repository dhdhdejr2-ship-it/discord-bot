import {
  Client,
  Message,
  PermissionFlagsBits,
  TextChannel,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import { warningsStore } from "../storage.js";
import { giveawaysStore } from "../storage.js";
import { scheduleGiveawayEnd } from "../giveawayRunner.js";
import { config } from "../config.js";
import { GIVEAWAY_BUTTON_ID } from "../commands/giveaway.js";
import { TICKET_OPEN_BUTTON_ID } from "../commands/ticket.js";

const PREFIX = "!";
const NUMBER_EMOJI = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"];

function parseDuration(input: string): number | null {
  const match = input.trim().match(/^(\d+)\s*(s|sec|secs|m|min|mins|h|hr|hrs|d|day|days)$/i);
  if (!match) return null;
  const amount = Number(match[1]);
  const unit = match[2].toLowerCase();
  const multiplier = unit.startsWith("s") ? 1000 : unit.startsWith("m") ? 60000 : unit.startsWith("h") ? 3600000 : 86400000;
  return amount * multiplier;
}

function requirePerm(message: Message, perm: bigint): boolean {
  if (!message.member || !message.member.permissions.has(perm)) {
    void message.reply("You don't have permission to use that command.");
    return false;
  }
  return true;
}

export function registerMessageCreateEvent(client: Client): void {
  client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild || !message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
    const commandName = args.shift()?.toLowerCase();
    if (!commandName) return;

    const targetUser = message.mentions.users.first();
    const targetMember = message.mentions.members?.first();

    try {
      switch (commandName) {
        case "ban": {
          if (!requirePerm(message, PermissionFlagsBits.BanMembers)) return;
          if (!targetMember) return void message.reply("Mention a user to ban. Usage: `!ban @user [reason]`");
          if (!targetMember.bannable) return void message.reply("I can't ban that member.");
          const reason = args.slice(1).join(" ") || "No reason provided";
          await message.guild.members.ban(targetMember.id, { reason });
          await message.reply(`🔨 Banned **${targetUser!.tag}** — ${reason}`);
          break;
        }

        case "unban": {
          if (!requirePerm(message, PermissionFlagsBits.BanMembers)) return;
          const userId = args[0];
          if (!userId) return void message.reply("Usage: `!unban <user_id> [reason]`");
          const reason = args.slice(1).join(" ") || "No reason provided";
          await message.guild.members.unban(userId, reason);
          await message.reply(`✅ Unbanned user \`${userId}\` — ${reason}`);
          break;
        }

        case "kick": {
          if (!requirePerm(message, PermissionFlagsBits.KickMembers)) return;
          if (!targetMember) return void message.reply("Mention a user to kick. Usage: `!kick @user [reason]`");
          if (!targetMember.kickable) return void message.reply("I can't kick that member.");
          const reason = args.slice(1).join(" ") || "No reason provided";
          await targetMember.kick(reason);
          await message.reply(`👢 Kicked **${targetUser!.tag}** — ${reason}`);
          break;
        }

        case "timeout": {
          if (!requirePerm(message, PermissionFlagsBits.ModerateMembers)) return;
          const minutes = Number(args[1]);
          if (!targetMember || !minutes) return void message.reply("Usage: `!timeout @user <minutes> [reason]`");
          if (!targetMember.moderatable) return void message.reply("I can't timeout that member.");
          const reason = args.slice(2).join(" ") || "No reason provided";
          await targetMember.timeout(minutes * 60 * 1000, reason);
          await message.reply(`⏱️ Timed out **${targetUser!.tag}** for ${minutes} minute(s) — ${reason}`);
          break;
        }

        case "untimeout": {
          if (!requirePerm(message, PermissionFlagsBits.ModerateMembers)) return;
          if (!targetMember) return void message.reply("Usage: `!untimeout @user [reason]`");
          const reason = args.slice(1).join(" ") || "No reason provided";
          await targetMember.timeout(null, reason);
          await message.reply(`✅ Removed timeout from **${targetUser!.tag}** — ${reason}`);
          break;
        }

        case "warn": {
          if (!requirePerm(message, PermissionFlagsBits.ModerateMembers)) return;
          const reason = args.slice(1).join(" ");
          if (!targetUser || !reason) return void message.reply("Usage: `!warn @user <reason>`");
          warningsStore.add({
            id: `${Date.now()}-${targetUser.id}`,
            userId: targetUser.id,
            guildId: message.guild.id,
            moderatorId: message.author.id,
            reason,
            createdAt: new Date().toISOString(),
          });
          const count = warningsStore.forUser(message.guild.id, targetUser.id).length;
          await message.reply(`⚠️ Warned **${targetUser.tag}** — ${reason} (total warnings: ${count})`);
          await targetUser.send(`You were warned in **${message.guild.name}**: ${reason}`).catch(() => {});
          break;
        }

        case "warnings": {
          if (!requirePerm(message, PermissionFlagsBits.ModerateMembers)) return;
          if (!targetUser) return void message.reply("Usage: `!warnings @user`");
          const list = warningsStore.forUser(message.guild.id, targetUser.id);
          if (list.length === 0) return void message.reply(`**${targetUser.tag}** has no warnings.`);
          const embed = new EmbedBuilder()
            .setTitle(`Warnings for ${targetUser.tag}`)
            .setColor(0xf5a623)
            .setDescription(list.map((w, i) => `**${i + 1}.** ${w.reason}`).join("\n"));
          await message.reply({ embeds: [embed] });
          break;
        }

        case "clearwarnings": {
          if (!requirePerm(message, PermissionFlagsBits.ModerateMembers)) return;
          if (!targetUser) return void message.reply("Usage: `!clearwarnings @user`");
          const removed = warningsStore.clear(message.guild.id, targetUser.id);
          await message.reply(`🧼 Cleared ${removed} warning(s) for **${targetUser.tag}**.`);
          break;
        }

        case "purge": {
          if (!requirePerm(message, PermissionFlagsBits.ManageMessages)) return;
          const amount = Number(args[0]);
          if (!amount || amount < 1 || amount > 100) return void message.reply("Usage: `!purge <1-100>`");
          if (!(message.channel instanceof TextChannel)) return;
          const messages = await message.channel.messages.fetch({ limit: amount + 1 });
          const deleted = await message.channel.bulkDelete(messages, true);
          const notice = await message.channel.send(`🧹 Deleted ${deleted.size - 1} message(s).`);
          setTimeout(() => void notice.delete().catch(() => {}), 4000);
          break;
        }

        case "lock": {
          if (!requirePerm(message, PermissionFlagsBits.ManageChannels)) return;
          if (!(message.channel instanceof TextChannel)) return;
          await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false });
          await message.reply("🔒 Channel locked.");
          break;
        }

        case "unlock": {
          if (!requirePerm(message, PermissionFlagsBits.ManageChannels)) return;
          if (!(message.channel instanceof TextChannel)) return;
          await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null });
          await message.reply("🔓 Channel unlocked.");
          break;
        }

        case "say": {
          if (!requirePerm(message, PermissionFlagsBits.ManageMessages)) return;
          const text = args.join(" ");
          if (!text) return void message.reply("Usage: `!say <message>`");
          if (message.deletable) await message.delete().catch(() => {});
          if (message.channel instanceof TextChannel) await message.channel.send(text);
          break;
        }

        case "roll": {
          const sides = Number(args[0]) || 6;
          const count = Math.min(Number(args[1]) || 1, 10);
          const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1);
          await message.reply(
            count === 1 ? `🎲 You rolled a **${rolls[0]}** (d${sides})` : `🎲 You rolled: ${rolls.join(", ")} (d${sides})`,
          );
          break;
        }

        case "coinflip": {
          await message.reply(`🪙 **${Math.random() < 0.5 ? "Heads" : "Tails"}**!`);
          break;
        }

        case "poll": {
          const parts = message.content.slice(PREFIX.length + "poll".length).trim().split("|").map((p) => p.trim()).filter(Boolean);
          if (parts.length < 3) return void message.reply("Usage: `!poll Question? | Option 1 | Option 2 | ...` (up to 5 options)");
          const [question, ...options] = parts;
          const embed = new EmbedBuilder()
            .setTitle(`📊 ${question}`)
            .setColor(0x5865f2)
            .setDescription(options.slice(0, 5).map((o, i) => `${NUMBER_EMOJI[i]} ${o}`).join("\n"))
            .setFooter({ text: `Poll started by ${message.author.tag}` });
          const sent = await message.channel.send({ embeds: [embed] });
          for (let i = 0; i < Math.min(options.length, 5); i++) await sent.react(NUMBER_EMOJI[i]);
          break;
        }

        case "giveaway": {
          if (!requirePerm(message, PermissionFlagsBits.ManageGuild)) return;
          // !giveaway <duration> <winners> <prize...>
          const durationMs = parseDuration(args[0] || "");
          const winnerCount = Number(args[1]);
          const prize = args.slice(2).join(" ");
          if (!durationMs || !winnerCount || !prize) {
            return void message.reply("Usage: `!giveaway <duration e.g. 10m> <winners> <prize>`");
          }
          if (!(message.channel instanceof TextChannel)) return;
          const endsAt = new Date(Date.now() + durationMs);
          const embed = new EmbedBuilder()
            .setTitle("🎉 Giveaway!")
            .setColor(0x57f287)
            .setDescription(`**Prize:** ${prize}\n**Winners:** ${winnerCount}\nEnds <t:${Math.floor(endsAt.getTime() / 1000)}:R>`)
            .setFooter({ text: `Hosted by ${message.author.tag}` });
          const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(GIVEAWAY_BUTTON_ID).setLabel("🎉 Enter").setStyle(ButtonStyle.Success),
          );
          const sent = await message.channel.send({ embeds: [embed], components: [row] });
          giveawaysStore.add({
            messageId: sent.id,
            channelId: message.channel.id,
            guildId: message.guild.id,
            prize,
            winnerCount,
            endsAt: endsAt.toISOString(),
            participants: [],
            ended: false,
          });
          scheduleGiveawayEnd(message.client, sent.id, durationMs);
          break;
        }

        case "ticket-setup":
        case "ticketsetup": {
          if (!requirePerm(message, PermissionFlagsBits.ManageChannels)) return;
          if (!config.ticketCategoryId) {
            return void message.reply("Set the TICKET_CATEGORY_ID environment variable to a category channel ID first.");
          }
          const embed = new EmbedBuilder()
            .setTitle(args.join(" ") || "Need help?")
            .setDescription("Click the button below to open a private ticket with the staff team.")
            .setColor(0x5865f2);
          const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(TICKET_OPEN_BUTTON_ID).setLabel("🎫 Open Ticket").setStyle(ButtonStyle.Primary),
          );
          if (message.channel instanceof TextChannel) await message.channel.send({ embeds: [embed], components: [row] });
          break;
        }

        default:
          return;
      }
    } catch (error) {
      console.error(`Error running !${commandName}:`, error);
      await message.reply("Something went wrong running that command.").catch(() => {});
    }
  });
}
