import { Client } from "discord.js";
import { commandsByName } from "../commands/index.js";
import { GIVEAWAY_BUTTON_ID } from "../commands/giveaway.js";
import { TICKET_OPEN_BUTTON_ID, TICKET_CLOSE_BUTTON_ID, handleTicketOpen, handleTicketClose } from "../commands/ticket.js";
import { giveawaysStore, ticketCounterStore } from "../storage.js";

export function registerInteractionCreateEvent(client: Client): void {
  client.on("interactionCreate", async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        const command = commandsByName.get(interaction.commandName);
        if (!command) return;
        await command.execute(interaction);
        return;
      }

      if (interaction.isButton()) {
        if (interaction.customId === GIVEAWAY_BUTTON_ID) {
          const added = giveawaysStore.addParticipant(interaction.message.id, interaction.user.id);
          await interaction.reply({
            content: added ? "🎉 You're entered!" : "You've already entered this giveaway (or it has ended).",
            ephemeral: true,
          });
          return;
        }

        if (interaction.customId === TICKET_OPEN_BUTTON_ID && interaction.guild) {
          const ticketNumber = ticketCounterStore.next(interaction.guild.id);
          await handleTicketOpen(interaction, ticketNumber);
          return;
        }

        if (interaction.customId === TICKET_CLOSE_BUTTON_ID) {
          await handleTicketClose(interaction);
          return;
        }
      }
    } catch (error) {
      console.error("Error handling interaction:", error);
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: "Something went wrong running that command.", ephemeral: true }).catch(() => {});
      }
    }
  });
}
