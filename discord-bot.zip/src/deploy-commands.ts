import { REST, Routes } from "discord.js";
import { config } from "./config.js";
import { commands } from "./commands/index.js";

const rest = new REST().setToken(config.token);

const body = commands.map((c) => c.data.toJSON());

async function main() {
  const route = config.guildId
    ? Routes.applicationGuildCommands(config.clientId, config.guildId)
    : Routes.applicationCommands(config.clientId);

  console.log(
    config.guildId
      ? `Registering ${body.length} commands to guild ${config.guildId} (instant)...`
      : `Registering ${body.length} commands globally (can take up to 1 hour to propagate)...`,
  );

  await rest.put(route, { body });
  console.log("Done.");
}

main().catch((error) => {
  console.error("Failed to register commands:", error);
  process.exit(1);
});
