import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import path from "node:path";

// Simple JSON-file storage. This bot is meant to run as a single process
// (one Railway service), so a local file is enough -- no database required.
const dataDir = path.join(process.cwd(), "data");
if (!existsSync(dataDir)) {
  mkdirSync(dataDir, { recursive: true });
}

function loadFile<T>(name: string, fallback: T): T {
  const filePath = path.join(dataDir, name);
  if (!existsSync(filePath)) return fallback;
  try {
    return JSON.parse(readFileSync(filePath, "utf-8")) as T;
  } catch {
    return fallback;
  }
}

function saveFile<T>(name: string, data: T): void {
  writeFileSync(path.join(dataDir, name), JSON.stringify(data, null, 2));
}

export interface Warning {
  id: string;
  userId: string;
  guildId: string;
  moderatorId: string;
  reason: string;
  createdAt: string;
}

export interface Giveaway {
  messageId: string;
  channelId: string;
  guildId: string;
  prize: string;
  winnerCount: number;
  endsAt: string;
  participants: string[];
  ended: boolean;
}

export interface TicketCounter {
  [guildId: string]: number;
}

let warnings = loadFile<Warning[]>("warnings.json", []);
let giveaways = loadFile<Giveaway[]>("giveaways.json", []);
let ticketCounters = loadFile<TicketCounter>("ticket-counters.json", {});

export const warningsStore = {
  all(): Warning[] {
    return warnings;
  },
  forUser(guildId: string, userId: string): Warning[] {
    return warnings.filter((w) => w.guildId === guildId && w.userId === userId);
  },
  add(warning: Warning): void {
    warnings.push(warning);
    saveFile("warnings.json", warnings);
  },
  clear(guildId: string, userId: string): number {
    const before = warnings.length;
    warnings = warnings.filter((w) => !(w.guildId === guildId && w.userId === userId));
    saveFile("warnings.json", warnings);
    return before - warnings.length;
  },
};

export const giveawaysStore = {
  all(): Giveaway[] {
    return giveaways;
  },
  add(giveaway: Giveaway): void {
    giveaways.push(giveaway);
    saveFile("giveaways.json", giveaways);
  },
  findByMessageId(messageId: string): Giveaway | undefined {
    return giveaways.find((g) => g.messageId === messageId);
  },
  addParticipant(messageId: string, userId: string): boolean {
    const giveaway = giveaways.find((g) => g.messageId === messageId);
    if (!giveaway || giveaway.ended) return false;
    if (giveaway.participants.includes(userId)) return false;
    giveaway.participants.push(userId);
    saveFile("giveaways.json", giveaways);
    return true;
  },
  markEnded(messageId: string): void {
    const giveaway = giveaways.find((g) => g.messageId === messageId);
    if (giveaway) {
      giveaway.ended = true;
      saveFile("giveaways.json", giveaways);
    }
  },
};

export const ticketCounterStore = {
  next(guildId: string): number {
    ticketCounters[guildId] = (ticketCounters[guildId] || 0) + 1;
    saveFile("ticket-counters.json", ticketCounters);
    return ticketCounters[guildId];
  },
};
