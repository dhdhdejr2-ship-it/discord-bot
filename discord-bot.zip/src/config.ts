function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

export const config = {
  token: required("DISCORD_TOKEN"),
  clientId: required("CLIENT_ID"),
  guildId: process.env.GUILD_ID || undefined,
  welcomeChannelId: process.env.WELCOME_CHANNEL_ID || undefined,
  leaveChannelId: process.env.LEAVE_CHANNEL_ID || undefined,
  ticketCategoryId: process.env.TICKET_CATEGORY_ID || undefined,
};
