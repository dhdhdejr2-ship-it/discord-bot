import { Client, GatewayIntentBits, Partials } from "discord.js";
import { config } from "./config.js";
import { registerReadyEvent } from "./events/ready.js";
import { registerInteractionCreateEvent } from "./events/interactionCreate.js";
import { registerWelcomeLeaveEvents } from "./events/welcomeLeave.js";
import { registerMessageCreateEvent } from "./events/messageCreate.js";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

registerReadyEvent(client);
registerInteractionCreateEvent(client);
registerWelcomeLeaveEvents(client);
registerMessageCreateEvent(client);

client.login(config.token);
