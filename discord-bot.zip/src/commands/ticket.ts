import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
} from "discord.js";
import type { SlashCommand } from "./types.js";
import { config } from "../config.js";

export const TICKET_OPEN_BUTTON_ID = "ticket_open";
export const TICKET_CLOSE_BUTTON_ID = "ticket_close";

export const ticketSetup: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("ticket-setup")
    .setDescription("Post the ticket panel in this channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addStringOption((o) => o.setName("title").setDescription("Panel title"))
    .addStringOption((o) => o.setName("description").setDescription("Panel description")),
  async execute(interaction) {
    if (!interaction.guild) {
      await interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
      return;
    }

    if (!config.ticketCategoryId) {
      await interaction.reply({
        content: "Set the TICKET_CATEGORY_ID environment variable to a category channel ID first, then try again.",
        ephemeral: true,
      });
      return;
    }

    const title = interaction.options.getString("title") || "Need help?";
    const description =
      interaction.options.getString("description") ||
      "Click the button below to open a private ticket with the staff team.";

    const embed = new EmbedBuilder().setTitle(title).setDescription(description).setColor(0x5865f2);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(TICKET_OPEN_BUTTON_ID).setLabel("🎫 Open Ticket").setStyle(ButtonStyle.Primary),
    );

    if (interaction.channel?.isTextBased() && "send" in interaction.channel) {
      await interaction.channel.send({ embeds: [embed], components: [row] });
    }

    await interaction.reply({ content: "Ticket panel posted.", ephemeral: true });
  },
};

export async function handleTicketOpen(interaction: import("discord.js").ButtonInteraction, ticketNumber: number) {
  if (!interaction.guild) return;

  const channelName = `ticket-${ticketNumber}`;
  const channel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: config.ticketCategoryId,
    permissionOverwrites: [
      { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: interaction.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
      {
        id: interaction.client.user!.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
    ],
  });

  const embed = new EmbedBuilder()
    .setTitle(`Ticket #${ticketNumber}`)
    .setDescription(`Hey <@${interaction.user.id}>, staff will be with you shortly. Describe your issue below.`)
    .setColor(0x5865f2);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(TICKET_CLOSE_BUTTON_ID).setLabel("🔒 Close Ticket").setStyle(ButtonStyle.Danger),
  );

  await channel.send({ embeds: [embed], components: [row] });
  await interaction.reply({ content: `Ticket created: ${channel}`, ephemeral: true });
}

export async function handleTicketClose(interaction: import("discord.js").ButtonInteraction) {
  await interaction.reply("🔒 Closing this ticket in 5 seconds...");
  setTimeout(() => {
    if (interaction.channel && "delete" in interaction.channel) {
      void (interaction.channel as any).delete("Ticket closed");
    }
  }, 5000);
}
