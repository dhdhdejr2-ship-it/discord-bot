import type { SlashCommand } from "./types.js";
import { ban } from "./moderation/ban.js";
import { unban } from "./moderation/unban.js";
import { kick } from "./moderation/kick.js";
import { timeout } from "./moderation/timeout.js";
import { untimeout } from "./moderation/untimeout.js";
import { purge } from "./moderation/purge.js";
import { warn } from "./moderation/warn.js";
import { warnings } from "./moderation/warnings.js";
import { lock } from "./moderation/lock.js";
import { unlock } from "./moderation/unlock.js";
import { roll } from "./fun/roll.js";
import { coinflip } from "./fun/coinflip.js";
import { say } from "./fun/say.js";
import { poll } from "./poll.js";
import { giveaway } from "./giveaway.js";
import { ticketSetup } from "./ticket.js";

export const commands: SlashCommand[] = [
  ban,
  unban,
  kick,
  timeout,
  untimeout,
  purge,
  warn,
  warnings,
  lock,
  unlock,
  roll,
  coinflip,
  say,
  poll,
  giveaway,
  ticketSetup,
];

export const commandsByName = new Map(commands.map((c) => [c.data.name, c]));
