import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import type { SlashCommand } from "../types.js";

export const unban: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Unban a user by ID")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((o) => o.setName("user_id").setDescription("User ID to unban").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for unbanning")),
  async execute(interaction) {
    const userId = interaction.options.getString("user_id", true);
    const reason = interaction.options.getString("reason") || "No reason provided";

    if (!interaction.guild) {
      await interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
      return;
    }

    try {
      await interaction.guild.members.unban(userId, reason);
      await interaction.reply(`✅ Unbanned user \`${userId}\` — ${reason}`);
    } catch {
      await interaction.reply({ content: "Couldn't unban that user. Check the ID and that they're actually banned.", ephemeral: true });
    }
  },
};
