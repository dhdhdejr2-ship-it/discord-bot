import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from "discord.js";
import type { SlashCommand } from "../types.js";

export const lock: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("lock")
    .setDescription("Lock this channel so @everyone can't send messages")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addStringOption((o) => o.setName("reason").setDescription("Reason for locking")),
  async execute(interaction) {
    const reason = interaction.options.getString("reason") || "No reason provided";

    if (!interaction.guild || !(interaction.channel instanceof TextChannel)) {
      await interaction.reply({ content: "This command can only be used in a server text channel.", ephemeral: true });
      return;
    }

    await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
      SendMessages: false,
    });

    await interaction.reply(`🔒 Channel locked — ${reason}`);
  },
};
