import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import type { SlashCommand } from "../types.js";

export const untimeout: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("untimeout")
    .setDescription("Remove a timeout from a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName("user").setDescription("User to remove timeout from").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for removing the timeout")),
  async execute(interaction) {
    const target = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason") || "No reason provided";

    if (!interaction.guild) {
      await interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
      return;
    }

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) {
      await interaction.reply({ content: "Couldn't find that member.", ephemeral: true });
      return;
    }

    await member.timeout(null, reason);
    await interaction.reply(`✅ Removed timeout from **${target.tag}** — ${reason}`);
  },
};
