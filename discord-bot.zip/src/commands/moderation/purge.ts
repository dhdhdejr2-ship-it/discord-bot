import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from "discord.js";
import type { SlashCommand } from "../types.js";

export const purge: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("purge")
    .setDescription("Bulk delete recent messages in this channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((o) =>
      o
        .setName("amount")
        .setDescription("Number of messages to delete (1-100)")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100),
    )
    .addUserOption((o) => o.setName("user").setDescription("Only delete messages from this user")),
  async execute(interaction) {
    const amount = interaction.options.getInteger("amount", true);
    const user = interaction.options.getUser("user");

    if (!(interaction.channel instanceof TextChannel)) {
      await interaction.reply({ content: "This command can only be used in a text channel.", ephemeral: true });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    const filtered = (user ? messages.filter((m) => m.author.id === user.id) : messages).first(amount);

    const deleted = await interaction.channel.bulkDelete(filtered, true);
    await interaction.editReply(`🧹 Deleted ${deleted.size} message(s).`);
  },
};
