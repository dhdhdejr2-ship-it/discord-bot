import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";
import type { SlashCommand } from "../types.js";
import { warningsStore } from "../../storage.js";

export const warnings: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("View or clear a member's warnings")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((sub) =>
      sub
        .setName("list")
        .setDescription("List a member's warnings")
        .addUserOption((o) => o.setName("user").setDescription("User to check").setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName("clear")
        .setDescription("Clear a member's warnings")
        .addUserOption((o) => o.setName("user").setDescription("User to clear").setRequired(true)),
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      await interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
      return;
    }

    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser("user", true);

    if (sub === "clear") {
      const removed = warningsStore.clear(interaction.guild.id, target.id);
      await interaction.reply(`🧼 Cleared ${removed} warning(s) for **${target.tag}**.`);
      return;
    }

    const list = warningsStore.forUser(interaction.guild.id, target.id);
    if (list.length === 0) {
      await interaction.reply({ content: `**${target.tag}** has no warnings.`, ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`Warnings for ${target.tag}`)
      .setColor(0xf5a623)
      .setDescription(
        list
          .map((w, i) => `**${i + 1}.** ${w.reason} — <t:${Math.floor(new Date(w.createdAt).getTime() / 1000)}:R>`)
          .join("\n"),
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
