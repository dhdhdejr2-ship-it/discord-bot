import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import type { SlashCommand } from "../types.js";
import { warningsStore } from "../../storage.js";

export const warn: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Issue a warning to a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName("user").setDescription("User to warn").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for the warning").setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason", true);

    if (!interaction.guild) {
      await interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
      return;
    }

    warningsStore.add({
      id: `${Date.now()}-${target.id}`,
      userId: target.id,
      guildId: interaction.guild.id,
      moderatorId: interaction.user.id,
      reason,
      createdAt: new Date().toISOString(),
    });

    const count = warningsStore.forUser(interaction.guild.id, target.id).length;
    await interaction.reply(`⚠️ Warned **${target.tag}** — ${reason} (total warnings: ${count})`);

    await target.send(`You were warned in **${interaction.guild.name}**: ${reason}`).catch(() => {
      // user has DMs closed -- ignore
    });
  },
};
