import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from "discord.js";
import type { SlashCommand } from "../types.js";

export const unlock: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("unlock")
    .setDescription("Unlock this channel so @everyone can send messages again")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction) {
    if (!interaction.guild || !(interaction.channel instanceof TextChannel)) {
      await interaction.reply({ content: "This command can only be used in a server text channel.", ephemeral: true });
      return;
    }

    await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
      SendMessages: null,
    });

    await interaction.reply("🔓 Channel unlocked.");
  },
};
