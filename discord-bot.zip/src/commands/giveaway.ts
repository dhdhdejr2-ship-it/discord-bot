import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  TextChannel,
} from "discord.js";
import type { SlashCommand } from "./types.js";
import { giveawaysStore } from "../storage.js";
import { scheduleGiveawayEnd } from "../giveawayRunner.js";

function parseDuration(input: string): number | null {
  const match = input.trim().match(/^(\d+)\s*(s|sec|secs|m|min|mins|h|hr|hrs|d|day|days)$/i);
  if (!match) return null;
  const amount = Number(match[1]);
  const unit = match[2].toLowerCase();
  const multiplier = unit.startsWith("s")
    ? 1000
    : unit.startsWith("m")
      ? 60 * 1000
      : unit.startsWith("h")
        ? 60 * 60 * 1000
        : 24 * 60 * 60 * 1000;
  return amount * multiplier;
}

export const GIVEAWAY_BUTTON_ID = "giveaway_enter";

export const giveaway: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("giveaway")
    .setDescription("Start a giveaway")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((o) => o.setName("prize").setDescription("What are you giving away?").setRequired(true))
    .addStringOption((o) =>
      o.setName("duration").setDescription("How long (e.g. 30s, 10m, 1h, 2d)").setRequired(true),
    )
    .addIntegerOption((o) =>
      o.setName("winners").setDescription("Number of winners (default: 1)").setMinValue(1).setMaxValue(20),
    ),
  async execute(interaction) {
    const prize = interaction.options.getString("prize", true);
    const durationInput = interaction.options.getString("duration", true);
    const winnerCount = interaction.options.getInteger("winners") ?? 1;
    const durationMs = parseDuration(durationInput);

    if (!durationMs) {
      await interaction.reply({
        content: "Couldn't parse that duration. Use something like `30s`, `10m`, `1h`, or `2d`.",
        ephemeral: true,
      });
      return;
    }

    if (!interaction.guild || !(interaction.channel instanceof TextChannel)) {
      await interaction.reply({ content: "This command can only be used in a server text channel.", ephemeral: true });
      return;
    }

    const endsAt = new Date(Date.now() + durationMs);
    const embed = new EmbedBuilder()
      .setTitle("🎉 Giveaway!")
      .setColor(0x57f287)
      .setDescription(`**Prize:** ${prize}\n**Winners:** ${winnerCount}\nEnds <t:${Math.floor(endsAt.getTime() / 1000)}:R>`)
      .setFooter({ text: `Hosted by ${interaction.user.tag}` });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(GIVEAWAY_BUTTON_ID).setLabel("🎉 Enter").setStyle(ButtonStyle.Success),
    );

    await interaction.reply({ embeds: [embed], components: [row] });
    const message = await interaction.fetchReply();

    giveawaysStore.add({
      messageId: message.id,
      channelId: interaction.channel.id,
      guildId: interaction.guild.id,
      prize,
      winnerCount,
      endsAt: endsAt.toISOString(),
      participants: [],
      ended: false,
    });

    scheduleGiveawayEnd(interaction.client, message.id, durationMs);
  },
};
