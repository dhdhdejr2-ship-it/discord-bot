import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { SlashCommand } from "./types.js";

const NUMBER_EMOJI = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"];

export const poll: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("poll")
    .setDescription("Start a quick poll")
    .addStringOption((o) => o.setName("question").setDescription("The poll question").setRequired(true))
    .addStringOption((o) => o.setName("option1").setDescription("Option 1").setRequired(true))
    .addStringOption((o) => o.setName("option2").setDescription("Option 2").setRequired(true))
    .addStringOption((o) => o.setName("option3").setDescription("Option 3"))
    .addStringOption((o) => o.setName("option4").setDescription("Option 4"))
    .addStringOption((o) => o.setName("option5").setDescription("Option 5")),
  async execute(interaction) {
    const question = interaction.options.getString("question", true);
    const options = [1, 2, 3, 4, 5]
      .map((n) => interaction.options.getString(`option${n}`))
      .filter((o): o is string => Boolean(o));

    const embed = new EmbedBuilder()
      .setTitle(`📊 ${question}`)
      .setColor(0x5865f2)
      .setDescription(options.map((o, i) => `${NUMBER_EMOJI[i]} ${o}`).join("\n"))
      .setFooter({ text: `Poll started by ${interaction.user.tag}` });

    await interaction.reply({ embeds: [embed] });
    const message = await interaction.fetchReply();
    for (let i = 0; i < options.length; i++) {
      await message.react(NUMBER_EMOJI[i]);
    }
  },
};
