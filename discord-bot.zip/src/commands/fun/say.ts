import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from "discord.js";
import type { SlashCommand } from "../types.js";

// Slash commands don't post a visible message from the user (the invocation
// is only shown to the user who ran it, or hidden entirely with an
// ephemeral reply), so there's no separate "delete the user's message" step
// needed -- the bot just posts the given text as itself.
export const say: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("say")
    .setDescription("Make the bot say something")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption((o) => o.setName("message").setDescription("What the bot should say").setRequired(true))
    .addChannelOption((o) => o.setName("channel").setDescription("Channel to post in (default: this channel)")),
  async execute(interaction) {
    const message = interaction.options.getString("message", true);
    const channelOption = interaction.options.getChannel("channel");
    const target = channelOption instanceof TextChannel ? channelOption : interaction.channel;

    if (!(target instanceof TextChannel)) {
      await interaction.reply({ content: "Pick a text channel to say that in.", ephemeral: true });
      return;
    }

    await target.send(message);
    await interaction.reply({ content: "Sent.", ephemeral: true });
  },
};
