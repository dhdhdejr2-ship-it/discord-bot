import { SlashCommandBuilder } from "discord.js";
import type { SlashCommand } from "../types.js";

export const roll: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("roll")
    .setDescription("Roll a dice")
    .addIntegerOption((o) =>
      o.setName("sides").setDescription("Number of sides (default: 6)").setMinValue(2).setMaxValue(1000),
    )
    .addIntegerOption((o) =>
      o.setName("count").setDescription("How many dice to roll (default: 1, max: 10)").setMinValue(1).setMaxValue(10),
    ),
  async execute(interaction) {
    const sides = interaction.options.getInteger("sides") ?? 6;
    const count = interaction.options.getInteger("count") ?? 1;
    const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1);
    const total = rolls.reduce((a, b) => a + b, 0);

    await interaction.reply(
      count === 1
        ? `🎲 You rolled a **${rolls[0]}** (d${sides})`
        : `🎲 You rolled: ${rolls.join(", ")} (d${sides}) — total **${total}**`,
    );
  },
};
